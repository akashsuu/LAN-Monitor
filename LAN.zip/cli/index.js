const { program } = require('commander');
const chalk = require('chalk');
const packageJson = require('../package.json');

const pingCommand = require('../commands/ping');
const scanCommand = require('../commands/scan');
const devicesCommand = require('../commands/devices');
const websiteCommand = require('../commands/website');
const serverCommand = require('../commands/server');
const portCommand = require('../commands/port');
const ethernetCommand = require('../commands/ethernet');
const internetCommand = require('../commands/internet');
const dashboardCommand = require('../commands/dashboard');
const reportCommand = require('../commands/report');
const alertsCommand = require('../commands/alerts');
const configCommand = require('../commands/config');
const helpCommand = require('../commands/help');
const statusCommand = require('../commands/status');
const doctorCommand = require('../commands/doctor');
const updateCommand = require('../commands/update');
const watchCommand = require('../commands/watch');
const infoCommand = require('../commands/info');
const topologyCommand = require('../commands/topology');
const trustCommand = require('../commands/trust');
const nicknameCommand = require('../commands/nickname');
const osCommand = require('../commands/os');
const trafficCommand = require('../commands/traffic');
const latencyCommand = require('../commands/latency');
const findCommand = require('../commands/find');
const groupCommand = require('../commands/group');

function createCLI() {
  program
    .name('ln')
    .description(chalk.cyan('LAN Monitor - Professional Network Monitoring CLI'))
    .version(packageJson.version, '-v, --version', 'Output the current version');

  program
    .command('help')
    .description('Display all available commands grouped by category')
    .action(() => helpCommand.execute());

  program
    .command('status')
    .description('Show overall system status')
    .action(() => statusCommand.execute());

  program
    .command('doctor')
    .description('Run diagnostics on the system')
    .action(() => doctorCommand.execute());

  program
    .command('update')
    .description('Check for updates')
    .action(() => updateCommand.execute());

  program
    .command('ping <host>')
    .description('Ping a host to check connectivity and latency')
    .option('--stats', 'Show extended latency statistics (packet loss, jitter, graph)')
    .action((host, options) => pingCommand.execute(host, options));

  program
    .command('scan')
    .description('Automatically scan local network')
    .option('-d, --deep', 'Perform a deep scan with additional details')
    .argument('[subnet]', 'Subnet to scan (e.g. 192.168.1.0/24)')
    .action((subnet, options) => scanCommand.execute(subnet, options));

  program
    .command('devices')
    .description('List all known devices')
    .option('--online', 'Show only online devices')
    .option('--offline', 'Show only offline devices')
    .action((options) => devicesCommand.list(options));

  program
    .command('device <ip>')
    .description('Show details for a specific device')
    .action((ip) => devicesCommand.detail(ip));

  program
    .command('website')
    .description('Manage monitored websites. Run without args to scan local network for web servers')
    .argument('[command]', 'Subcommand: scan, add, remove, list, check, history')
    .argument('[arg]', 'URL or name for the subcommand')
    .action((command, arg) => {
      if (!command || command === 'scan') {
        websiteCommand.scanLocal(arg);
        return;
      }
      const handlers = {
        add: (url) => websiteCommand.add(url),
        remove: (name) => websiteCommand.remove(name),
        list: () => websiteCommand.list(),
        check: (name) => websiteCommand.check(name),
        history: (name) => websiteCommand.history(name),
      };
      if (handlers[command]) {
        handlers[command](arg);
      } else {
        console.log(chalk.yellow('\n  Usage: ln website <command> [options]\n'));
        console.log(chalk.bold('  Commands:\n'));
        console.log('    scan      Scan local network for web servers (or: scan <ip>)');
        console.log('    add       Add a website to monitor');
        console.log('    remove    Remove a monitored website');
        console.log('    list      List all monitored websites');
        console.log('    check     Check a website status');
        console.log('    history   Show website monitoring history\n');
      }
    });

  program
    .command('server')
    .description('Monitor servers. Run without args to scan local network for servers')
    .argument('[command]', 'Subcommand: scan, add, list, stats, remove')
    .argument('[arg]', 'IP address or name')
    .action((command, arg) => {
      if (!command || command === 'scan') {
        serverCommand.scanLocal(arg);
        return;
      }
      const handlers = {
        add: (ip) => serverCommand.add(ip),
        list: () => serverCommand.list(),
        stats: (name) => serverCommand.stats(name),
        remove: (name) => serverCommand.remove(name),
      };
      if (handlers[command]) {
        handlers[command](arg);
      } else {
        console.log(chalk.yellow('\n  Usage: ln server <command> [options]\n'));
        console.log(chalk.bold('  Commands:\n'));
        console.log('    scan      Scan local network for servers');
        console.log('    add       Add a server to monitor');
        console.log('    list      List all monitored servers');
        console.log('    stats     Show server statistics');
        console.log('    remove    Remove a monitored server\n');
      }
    });

  program
    .command('port')
    .description('Check port status and scan ports')
    .argument('[host]', 'Hostname or IP address')
    .argument('[port]', 'Port number')
    .option('--top100', 'Scan top 100 ports (with scan subcommand)')
    .option('--all', 'Scan all 65535 ports (with scan subcommand)')
    .option('--fast', 'Quick scan of 28 key ports (with scan subcommand)')
    .option('--no-service', 'Skip service detection')
    .option('--export', 'Export scan results to JSON')
    .action((host, port, options) => {
      if (host === 'monitor') {
        portCommand.monitor();
      } else if (host === 'scan' && port) {
        portCommand.scan(port, options);
      } else if (host && port) {
        portCommand.check(host, port);
      } else {
        console.log(chalk.yellow('\n  Usage: ln port <host> <port>\n'));
        console.log(chalk.bold('  Examples:\n'));
        console.log('    ln port localhost 25565');
        console.log('    ln port scan 192.168.1.1');
        console.log('    ln port scan 192.168.1.1 --fast');
        console.log('    ln port scan 192.168.1.1 --top100');
        console.log('    ln port scan 192.168.1.1 --all');
        console.log('    ln port monitor\n');
      }
    });

  program
    .command('ports <host>')
    .description('Scan common ports on a host')
    .action((host) => portCommand.scan(host));

  program
    .command('ethernet')
    .description('Show ethernet/network adapter information')
    .option('--speed', 'Show connection speed')
    .option('--stats', 'Show network statistics')
    .option('--reset', 'Reset network adapter')
    .action((options) => ethernetCommand.execute(options));

  program
    .command('internet')
    .description('Show internet connection status and information')
    .action(() => internetCommand.status());

  program
    .command('publicip')
    .description('Show your public IP address')
    .action(() => internetCommand.publicIP());

  program
    .command('gateway')
    .description('Show default gateway information')
    .action(() => internetCommand.gateway());

  program
    .command('dns')
    .description('Show DNS information')
    .action(() => internetCommand.dns());

  program
    .command('speed')
    .description('Run a speed test')
    .action(() => internetCommand.speed());

  program
    .command('dashboard')
    .description('Start the dashboard (use --live for real-time terminal dashboard)')
    .option('--open', 'Open dashboard in browser')
    .option('--stop', 'Stop the dashboard')
    .option('--live', 'Show real-time live dashboard in terminal')
    .action((options) => dashboardCommand.execute(options));

  program
    .command('alerts')
    .description('Manage alerts')
    .option('--clear', 'Clear all alerts')
    .option('--enable', 'Enable alerts')
    .option('--disable', 'Disable alerts')
    .action((options) => alertsCommand.execute(options));

  program
    .command('report')
    .description('Generate network reports')
    .argument('[period]', 'Report period: today, week, month, html')
    .action((period) => reportCommand.generate(period || 'today'));

  program
    .command('export')
    .description('Export data')
    .argument('<format>', 'Export format: pdf, csv')
    .action((format) => reportCommand.export(format));

  program
    .command('config')
    .description('Manage configuration')
    .hook('preAction', (thisCommand) => {
      const subcommands = ['show', 'set', 'reset'];
      const args = thisCommand.args;
      if (!args.length || !subcommands.includes(args[0])) {
        configCommand.show();
        process.exit(0);
      }
    })
    .argument('[command]', 'Subcommand: show, set, reset')
    .argument('[key]', 'Config key')
    .argument('[value]', 'Config value')
    .action((command, key, value) => {
      const handlers = {
        show: () => configCommand.show(),
        set: (k, v) => configCommand.set(k, v),
        reset: () => configCommand.reset(),
      };
      if (handlers[command]) handlers[command](key, value);
    });

  program
    .command('watch')
    .description('Watch mode - continuously monitor network for device changes')
    .option('-i, --interval <seconds>', 'Check interval in seconds')
    .option('-d, --duration <minutes>', 'How long to watch (default: unlimited)')
    .action((options) => watchCommand.execute(options));

  program
    .command('info <ip>')
    .description('Show detailed information about a device')
    .action((ip) => infoCommand.execute(ip));

  program
    .command('topology')
    .description('Show network topology map')
    .action(() => topologyCommand.execute());

  program
    .command('trust')
    .description('Manage trusted devices')
    .argument('[command]', 'Subcommand: list, add, remove, check')
    .argument('[arg]', 'MAC address or argument')
    .argument('[label]', 'Label for trusted device')
    .action((command, arg, label) => {
      trustCommand.execute(command || 'list', arg, label);
    });

  program
    .command('nickname')
    .description('Manage device nicknames')
    .argument('[command]', 'Subcommand: list, set, remove')
    .argument('[arg]', 'MAC address for the subcommand')
    .argument('[name]', 'Nickname to set')
    .action((command, arg, name) => {
      nicknameCommand.execute(command || 'list', arg, name);
    });

  program
    .command('os <ip>')
    .description('Detect operating system of a device via TTL, ports, banners')
    .action((ip) => osCommand.execute(ip));

  program
    .command('traffic')
    .description('Monitor live network traffic (upload/download speeds)')
    .argument('[duration]', 'Monitoring duration in seconds (default: 30)')
    .action((duration) => trafficCommand.execute(duration));

  program
    .command('latency <host>')
    .description('Run a detailed latency test with packet loss and jitter measurement')
    .option('-c, --count <n>', 'Number of packets to send', '10')
    .action((host, options) => latencyCommand.execute(host, options));

  program
    .command('find <keyword>')
    .description('Search devices by IP, MAC, vendor, hostname, nickname, or status')
    .action((keyword) => findCommand.execute(keyword));

  program
    .command('group')
    .description('Manage device groups for organization')
    .argument('[command]', 'Subcommand: create, delete, add, remove, list, show')
    .argument('[name]', 'Group name')
    .argument('[arg]', 'IP address or target')
    .action((command, name, arg) => {
      groupCommand.execute(command || 'list', name, arg);
    });

  program.parse(process.argv);
}

module.exports = { createCLI };
